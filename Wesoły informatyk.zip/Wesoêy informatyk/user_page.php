<?php

@include 'config.php';

session_start();

if(!isset($_SESSION['user_name'])){
   header('location:login_form.php');
}

?>

<!DOCTYPE html>
<html lang="pl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Praktyki strona</title>
    <link rel="icon" type="image/x-icon" href="/photo/happyit.png">
    <link rel="stylesheet" href="CSS/reset.css">
    <link rel="stylesheet" href="CSS/style.css">
    <link rel="stylesheet" href="CSS/style-button-hs.css">
    <link rel="stylesheet" href="CSS/header.css">
    <link rel="stylesheet" href="CSS/footer.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
</head>
<body>
    <!-- MENU -->  
    <header>
        <nav class="navigation" id="panel-menu">
                    <img class="logo" src="photo/happyit.png" alt="WesolyInformatyk-logo">
    <div class="nav-menu-main">
            <a href="/Kalkulator-ip/index.php" class="menu">KALKULATOR IP</a>
            <a href="/Q&A/quiz.html" class="menu">Q&A</a>
            <a href="/zakres_materialu.html" class="menu">ZAKRES MATERIAŁU</a>
    </div>
    <div>
        <span class="checkbox-container">
          <input class="checkbox-trigger" type="checkbox"  />
          <span class="menu-content">
              <ul>
                <li><a class="color-link-menu-sliding" href="/user_page_profil.php">Profil</a></li>
                <li><a class="color-link-menu-sliding" href="/register_form.php">Stwórz konto!</a></li>
                <li><a class="color-link-menu-sliding" href="index.html">Wyloguj się!</a></li>
              </ul>
            <span class="hamburger-menu"></span>
            </div>
    </div>
        </nav>
    </header>
    <main>
        <div class="tresc-main">
                <h1 class="tytul-main">Cześć <span><?php echo $_SESSION['user_name'] ?></span></h1>
                </div>
<!-- Sekcja 1 -->               
            <div class="info1-panel-index" id="info1-panel">
                <div class="lewy-panel-info1">
                    <h2 class="tytul-info1-panel-index">Q&A - CO MUSISZ WIEDZIEĆ</h2>
                    <h5 class="tekst-info1-panel-index">Sprawdź swoją wiedze na egzamin zawodowy</br> czerwiec INF.02. Proste pytania i odpowiedzi!</h5>
                    <a href="/Q&A/quiz.html" class="button">SPRAWDŹ</a>
                </div>
                <div class="prawy-panel-info1">
                    <img class="photo" src= "photo/info-1.jpg">
                </div>
            </div>

            <div class="srodek-info1-panel-index" id="srodek-info1-panel"></div>
<!-- Sekcja 2 -->
            <div class="info2-panel-index" id="info2-panel">
                <div class="lewy-panel-info2">
                    <h2 class="tytul-info2-panel-index">ZAKRES MATERIAŁU - INF.02</h2>
                    <h5 class="tekst-info2-panel-index">Sprawdź jaki materiał musisz opanować</br> na egzamin zawodowy czerwiec INF.02</h5>
                    <a href="/zakres_materialu.html" class="button">SPRAWDŹ</a>
                </div>
                <div class="prawy-panel-info2">
                    <img class="photo" src= "photo/info-2.jpg">
                </div>
            </div>

            <div class="srodek-info2-panel-index" id="srodek-info2-panel"></div>
<!-- Sekcja 3 -->

<div class="panel-sekcja-3">
<div class="panel-3-kalkulator">
    <h2 class="kalkulator-napis">KALKULATOR IP</h2>
    <a href="/Kalkulator-ip/index.php" class="button-2">SPRAWDŹ</a>
</div>
<div class="panel-3-egzamin">
    <h2 class="kalkulator-napis">Q&A</h2>
    <a href="/Q&A/quiz.html" class="button-2">SPRAWDŹ</a>
</div>
</div>
<div class="srodek-3-panel" id="srodek-3-panel"></div>

<!-- Sekcja 4 -->
            <div class="panel-authors-main">
                <h1 class="tytul-main-4">TWÓRCY STRONY</h1>


                <div class="author-left">
                    <img class="photo-author" src= "photo/t64re6uyfdfdcter6w8eyfsdcre68y32uwefdchj.jpg">
                    <h3 class="title-author">Artur Falkiewicz</h3>
                </div>

                <div class="author-center">
                    <img class="photo-author" src= "photo/34yrfujhcrgif7fi7ufcgy4ueryugifdvucj.jpg">
                    <h3 class="title-author">Ania Nowicka</h3>
                </div>

                <div class="author-right">
                    <img class="photo-author" src= "photo/341510822_545981570782937_513157380739753339_n.jpg">
                    <h3 class="title-author">Mateusz Sałaciński</h3>
                </div>

            </div>
            <div class="srodek-4-panel" id="srodek-4-panel"></div>
    </main>
    <!-- STOPKA -->
    <footer class="stopka">    
        <div> 
            <p class="kontaktfr"> &copy; WesolyInformatyk.pl 2023  &nbsp; | &nbsp; </p>
                 <p class="kontakt" href="kontakt.html"> Kontakt &nbsp; | &nbsp; </p>

                   <ab id="11fcv" href="facebook.com" class="fa fa-facebook">
                   </ab>
                   <ab id="11fcv" href="twitter.com" class="fa fa-twitter"> 
                   </ab> 
                   <ab id="11fcv" href="instagram.com" class="fa fa-instagram">
                   </ab> 
            
        </div>
    </footer>
</body>
</html>
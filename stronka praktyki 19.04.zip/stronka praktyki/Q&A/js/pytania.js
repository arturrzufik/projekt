const quiz = [
    {
        q:'Do aktualizacji systemów Linux można wykorzystać programy:',
        options:
        ['cron i mount',
        'defrag i YaST',
        'apt-get i zipper',
        'aptitude i amaro'
        ],
        answer:2
    },
    {
        q:'Aby umożliwić komunikację urządzenia mobilnego z komputerem przez interfejs Bluetooth, należy:',
        options:
        ['skonfigurować urządzenie mobilne przez przeglądarkę.',
        'połączyć urządzenia kablem krosowym.',
        'utworzyć sieć WAN dla urządzeń.',
        'wykonać parowanie urządzeń.'],
        answer:3
    },
    {
        q:'Która licencja ma charakter grupowy oraz umożliwia instytucjom komercyjnym lub organizacjom edukacyjnym, państwowym, charytatywnym zakup na korzystnych warunkach większej liczby oprogramowania firmy Microsoft?',
        options:
        ['MPL',
        'OEM',
        'APSL',
        'MOLP'],
        answer:3
    },
    {
        q:'Topologia fizyczna sieci, w której jako medium transmisyjne stosuje się fale radiowe, jest nazywana topologią',
        options:
        ['ad-hoc',
        'magistrali',
        'pierścienia',
        'CSMA/CD'],
        answer:0
    },
    {
        q:'Który ze standardów Gigabit Ethernet umożliwia budowę segmentów sieci o długości 550 m/5000 m z prędkością transmisji 1 Gb/s?',
        options:
        ['1000Base-T',
        '1000Base-FX',
        '1000Base-LX',
        '1000Base-SX'],
        answer:0
    },
    {
        q:'Przedstawiony na rysunku symbol oznacza produkt',
        options:
        ['nadający się do powtórnego przetworzenia',
        'przeznaczony do powtórnego użycia',
        'biodegradowalny',
        'niebezpieczny'],
        answer:0,
        img:'photo/recykling.png'
   
    },
    {
        q:'Montaż przedstawionej karty graficznej będzie możliwy na płycie głównej wyposażonej w złącze',
        options:
        ['PCI-E x16',
        'PCI-E x4',
        'AGP x2',
        'AGP x8'],
        answer:0,
        img:'photo/karta.png'
    },
    {
        q:'Aby w systemie Windows przydzielić użytkownikowi prawo do zmiany czasu systemowego, należy użyć przystawki',
        options:
        ['eventvwr.msc',
        'certmgr.msc',
        'secpol.msc',
        'services.msc'],
        answer:2,
    },
    {
        q:'W celu dokonania aktualizacji zainstalowanego systemu operacyjnego Linux Ubuntu należy użyć polecenia',
        options:
        ['eventvwr.msc',
        'yum upgrade',
        'kernel update',
        'apt-get upgrade'],
        answer:3,
    },
    {
        q:'Zestaw reguł definiujących sposób przesyłania informacji w sieci opisuje',
        options:
        ['standard.',
        'zasada.',
        'protokół.',
        'reguła.'],
        answer:2,
    },
    {
        q:'Układy sekwencyjne zbudowane z zespołu przerzutników, najczęściej synchronicznych typu D, służące do przechowywania danych, to',
        options:
        ['bramki',
        'kodery',
        'rejestry',
        'dekodery'],
        answer:2
    },
    {
        q:'Kompatybilne podzespoły oznaczono w tabeli numerami',
        options:
        ['1, 3, 5',
        '1, 4, 6',
        '2, 4, 5',
        '2, 4, 6'],
        answer:2,
        img:'photo/podzespoly.jpg'
    },
    {
        q:'Przed rozpoczęciem modernizacji komputerów osobistych oraz serwerów, polegającej na dołożeniu nowych modułów pamięci RAM, należy sprawdzić',
        options:
        ['model pamięci RAM, maksymalną pojemność i liczbę modułów obsługiwaną przez płytę główną.',
        'pojemność i rodzaj interfejsu dysku twardego oraz rodzaj gniazda zainstalowanej pamięci RAM.',
        'producenta pamięci RAM oraz interfejsy zewnętrzne zainstalowanej płyty głównej.',
        'gniazdo interfejsu karty graficznej oraz moc zainstalowanego zasilacza.'],
        answer:0,
    },
    {
        q:'Aby można było wykorzystać aparat telefoniczny PSTN do wykonywania połączeń za pomocą sieci komputerowej, należy go podłączyć do',
        options:
        ['modemu analogowego',
        'mostka sieciowego',
        'repetera sygnału',
        'bramki VoIP'],
        answer:3,
    },
    {
        q:'Wskaż narzędzie służące do mocowania pojedynczych żył kabla miedzianego w złączach.',
        options:
        ['A',
        'B',
        'C',
        'D'],
        answer:1,
        img:'photo/narzedzia.jpg'
    },
    {
        q:'Który adres IP należy do klasy A?',
        options:
        ['239.0.255.15',
        '217.12.45.1',
        '129.10.0.17',
        '125.11.0.7'],
        answer:3,
    },
    {
        q:'Wskaż adres rozgłoszeniowy sieci, do której należy host o adresie 88.89.90.91/6?',
        options:
        ['91.255.255.255',
        '88.255.255.255',
        '91.89.255.255',
        '88.89.255.255'],
        answer:0,
    },
    {
        q:'Aby w systemie Windows wykonać śledzenie trasy pakietów do serwera strony internetowej, należy wykorzystać polecenie',
        options:
        ['ping',
        'tracert',
        'netstat',
        'iproute'],
        answer:1,
    },
    {
        q:'Na schemacie obrazującym zasadę działania monitora plazmowego numerem 6 oznaczono',
        options:
        ['warstwę fosforową.',
        'warstwę dielektryka.',
        'elektrody adresujące.',
        'elektrody wyświetlacza.'],
        answer:2,
        img:'photo/monitor.jpg'
    },
    {
        q:'Na ilustracji zaznaczono strzałkami funkcję przycisków znajdujących się na obudowie projektora multimedialnego. Za pomocą tych przycisków można',
        options:
        ['przełączać sygnały wejściowe',
        'regulować zniekształcony obraz.',
        'zmieniać poziom jasności obrazu.',
        'regulować odwzorowanie przestrzeni kolorów'],
        answer:1,
        img:'photo/projektor.jpg'
    },
    {
        q:'Pierwszą czynnością niezbędną do zabezpieczenia rutera przed dostępem do jego panelu konfiguracyjnego przez osoby niepowołane jest',
        options:
        ['włączenie filtrowania adresów MAC.',
        'włączenie szyfrowania kluczem WEP',
        'zmiana domyślnej nazwy sieci (SSID) na unikatową',
        'zmiana nazwy login i hasła wbudowanego konta administratora.'],
        answer:3,
    },
    {
        q:'Aby wyczyścić z kurzu wnętrze obudowy drukarki fotograficznej, należy użyć',
        options:
        ['sprężonego powietrza w pojemniku z wydłużoną rurką.',
        'szczotki z twardym włosiem',
        'opaski antystatycznej.',
        'środka smarującego.'],
        answer:0,
    },
    {
        q:'Na podstawie zrzutu ekranu przedstawiającego konfigurację przełącznika można stwierdzić, że',
        options:
        ['czas między wysyłaniem kolejnych komunikatów o poprawnej pracy urządzenia wynosi 3 sekundy.',
        'maksymalny czas krążenia w sieci komunikatów protokołu BPDU wynosi 20 sekund.',
        'minimalny czas krążenia w sieci komunikatów protokołu BPDU wynosi 25 sekund.',
        'maksymalny czas pomiędzy zmianami statusu łącza wynosi 5 sekund.'],
        answer:0,
        img:'photo/switch.jpg'
    },
    {
        q:'Przedstawione polecenia, uruchomione w interfejsie CLI rutera firmy CISCO, spowodują',
        options:
        ['dopuszczenie ruchu pochodzącego z sieci o adresie 10.0.0.1',
        'określenie puli adresów wewnętrznych 10.0.0.1 ÷ 255.255.255.0',
        'ustawienie interfejsu zewnętrznego o adresie 10.0.0.1/24 dla technologii NAT',
        'ustawienie interfejsu wewnętrznego o adresie 10.0.0.1/24 dla technologii NAT'],
        answer:0,
        img:'photo/cli.jpg'
    },
    {
        q:'Schemat przedstawia zasadę działania sieci VPN o nazwie',
        options:
        ['Site - to - Site',
        'Client - to -Site',
        'Gateway',
        'L2TP'],
        answer:0,
        img:'photo/vpn.jpg'
    },
    {
        q:'Przedstawione narzędzie może być wykorzystane do',
        options:
        ['pomiaru wartości napięcia w zasilaczu',
        'sprawdzenia długości badanego kabla sieciowego.',
        'podgrzania i zamontowania elementu elektronicznego.',
        'utrzymania drukarki w czystości.'],
        answer:0,
        img:'photo/narzedzie.jpg'
    },
    {
        q:'Wskaż program systemu Linux, służący do kompresji danych.',
        options:
        ['arj',
        'tar',
        'gzip',
        'shar'],
        answer:2,
    },
    {
        q:'Wskaż sygnał oznaczający błąd karty graficznej komputera wyposażonego w BIOS POST firmy AWARD.',
        options:
        ['1 długi, 2 krótkie.',
        '1 długi, 1 krótki.',
        '1 długi, 5 krótkich.',
        '1 długi, 9 krótkich.'],
        answer:0,
    },
    {
        q:'Po sprawdzeniu komputera programem diagnostycznym wykryto, że temperatura pracy karty graficznej posiadającej wyjścia HDMI i D-SUB, osadzonej w gnieździe PCI Express komputera stacjonarnego, wynosi 87°C. W takim przypadku serwisant powinien',
        options:
        ['sprawdzić, czy wentylator jest sprawny i czy nie jest zakurzony.',
        'zamienić kabel sygnałowy D-SUB na HDMI.',
        'zainstalować dodatkowy moduł pamięci RAM, aby odciążyć kartę.',
        'wymienić dysk twardy na nowy, o podobnej wielkości i prędkości obrotowej.'],
        answer:0,
    },
    {
        q:'SuperPi to program wykorzystywany do sprawdzenia',
        options:
        ['wydajności procesorów o zwiększonej częstotliwości.',
        'obciążenia i wydajności kart graficznych.',
        'ilości niewykorzystanej pamięci operacyjnej RAM.',
        'wydajności dysków twardych.'],
        answer:0,
    },
    {
        q:'Odzyskanie listy kontaktów w telefonie komórkowym z zainstalowanym systemem Android jest możliwe, gdy użytkownik wcześniej wykonał synchronizację danych urządzenia z Google Drive za pomocą',
        options:
        ['konta Google',
        'konta Yahoo',
        'konta Microsoft',
        'dowolnego konta pocztowego z portalu Onet'],
        answer:0,
    },
    {
        q:'Aby wyeliminować podstawowe zagrożenia związane z bezpieczeństwem pracy na komputerze podłączonym do sieci Internet, w pierwszej kolejności należy',
        options:
        ['zainstalować program antywirusowy, zaktualizować bazy wirusów, włączyć firewall i wykonać aktualizację systemu.',
        'odsunąć komputer od źródła ciepła, nie przygniatać przewodów zasilających komputera i urządzeń peryferyjnych.',
        'wyczyścić wnętrze jednostki centralnej, nie jeść i nie pić przy komputerze oraz nie podawać swojego hasła innym użytkownikom',
        'sprawdzić temperaturę podzespołów, podłączyć komputer do zasilacza UPS oraz nie wchodzić na podejrzane strony internetowe.'],
        answer:0,
    },
    {
        q:'Serwisant wykonał w ramach zlecenia czynności wymienione w tabeli. Koszt zlecenia obejmuje cenę usług zawartych w tabeli oraz koszt pracy serwisanta, którego stawka godzinowa wynosi 60,00 zł netto. Ustal całkowity koszt zlecenia brutto. Stawka podatku VAT na usługi wynosi 23%.',
        options:
        ['492,00 zł',
        '455,20 zł',
        '436,80 zł',
        '400,00 zł'],
        answer:0,
        img:'photo/serwis.jpg'
    },
    {
        q:'Aby w systemie Windows zmienić parametry konfiguracyjne Menu Start i paska zadań należy wykorzystać przystawkę',
        options:
        ['gpedit.msc',
        'azman.msc',
        'dcpol.msc',
        'fsmgmt.msc'],
        answer:0,
    },
    {
        q:'Konfigurację interfejsu sieciowego w systemie Linux można wykonać, edytując plik',
        options:
        ['/ etc / network / interfaces',
        '/ etc / host.conf',
        '/ etc / resolv.conf',
        '/ etc / hosts'],
        answer:0,
    },
    {
        q:'W systemie Linux polecenie touch służy do',
        options:
        ['utworzenia pliku lub zmiany daty modyfikacji lub daty ostatniego dostępu.',
        'obliczenia liczby wierszy, słów i znaków w pliku.',
        'wyszukania podanego wzorca w tekście pliku.',
        'przeniesienia lub zmiany nazwy pliku.'],
        answer:0,
    },
    {
        q:'Aby w systemie Windows Server wykonać rezerwację adresów IP na podstawie adresów fizycznych MAC urządzeń, należy skonfigurować usługę',
        options:
        ['DHCP',
        'RRAS',
        'NAT',
        'DNS'],
        answer:0,
    },
    {
        q:'Po wydaniu przedstawionego polecenia systemu Windows, wartość 11 zostanie ustawiona dla',
        options:
        ['minimalnej liczby znaków w hasłach użytkowników.',
        'maksymalnej liczby dni ważności konta.',
        'maksymalnej liczby dni między zmianami haseł użytkowników.',
        'minimalnej liczby minut, przez które użytkownik może być zalogowany.'],
        answer:0,
    },
    {
        q:'Protokół RDP jest wykorzystywany w usłudze',
        options:
        ['pulpitu zdalnego w systemie Windows.',
        'terminalowej w systemie Linux.',
        'SCP w systemie Windows.',
        'poczty elektronicznej w systemie Linux'],
        answer:0,
    },
    {
        q:'Narzędziem systemu Windows służącym do sprawdzenia prób logowania do systemu jest dziennik',
        options:
        ['zabezpieczeń',
        'aplikacji',
        'System',
        'Setup'],
        answer:0,
    }
]
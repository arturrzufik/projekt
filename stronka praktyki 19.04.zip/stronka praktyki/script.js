const pytanie = [
    {
        question: "Super pytanie JD?",
        answers: [
            {text: "jablko", correct: false},
            {text: "japko", correct: true},
            {text: "jabułko", correct: false},
            {text: "JD", correct: false},
        ]
    },
     {
        question: "Super zajebise pytanie JD?",
        answers: [
            {text: "banan", correct: false},
            {text: "banana", correct: true},
            {text: "bananas", correct: false},
            {text: "banananan", correct: false},
        ]
    },
    {
        question: "Super spontaniczne pytanie JD?",
        answers: [
            {text: "pomidor", correct: false},
            {text: "owoc", correct: true},
            {text: "warzywo", correct: false},
            {text: "warzywa", correct: false},
        ]
    },
    {
        question: "Super ekstra pytanie JD?",
        answers: [
            {text: "dupa", correct: false},
            {text: "dupsko", correct: true},
            {text: "dudupa", correct: false},
            {text: "dupadupa", correct: false},
        ]
    },
    {
        question: "Super dojebane pytanie JD?",
        answers: [
            {text: "XD", correct: false},
            {text: "xd", correct: true},
            {text: "Xd", correct: false},
            {text: "xD", correct: false},
        ]
    }
];

const questionElement = document.getElementById("question");
const answerButtons = document.getElementById("answer-buttons");
const nextButton = document.getElementById("next-btn");

let currentQuestionIndex = 0;
let score = 0;

function startQuiz(){
    currentQuestionIndex = 0;
    score = 0;
    nextButton.innerHTML = "Next";
    showQuestion();
}
function showQuestion(){
    resetState();
    let currentQuestion = question[currentQuestionIndex];
    let questionNo = currentQuestionIndex + 1;
    questionElement.innerHTML = questionNo + "." + currentQuestion.question;
   
    currentQuestion.answers.forEach(answer => {
        const button = document.createElement("button");
        button.innerHTML = answer.text;
        button.classList.add("btn");
        answerButtons.appendChild(button);
    });
}

function resetState(){
    nextButton.style.display = "none";
    while(answerButtons.firstChild){
        answerButtons.removeChild(answerButtons.firstChild);
    }
}


startQuiz();
